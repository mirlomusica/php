<?php

$nbaQuest = [
    ["quest" => "Qui va guanyar 10 vegades la NBA?", 
     "a)" => "Michael Jordan", 
     "b)" => "Kobe Bryant", 
     "c)" => "Bill Russell", 
     "resp" => "Bill Russell"],

    ["quest" => "Quin jugador és conegut com 'His Airness'?", 
     "a)" => "Michael Jordan", 
     "b)" => "LeBron James", 
     "c)" => "Shaquille O'Neal", 
     "resp" => "Michael Jordan"],

    ["quest" => "Quin equip va guanyar el primer títol de la NBA?", 
     "a)" => "Boston Celtics", 
     "b)" => "Philadelphia Warriors", 
     "c)" => "New York Knicks", 
     "resp" => "Philadelphia Warriors"],

    ["quest" => "Qui és el màxim anotador històric de la NBA (fins 2024)?", 
     "a)" => "Kareem Abdul-Jabbar", 
     "b)" => "LeBron James", 
     "c)" => "Michael Jordan", 
     "resp" => "LeBron James"],

    ["quest" => "Quin jugador va fer 100 punts en un partit?", 
     "a)" => "Wilt Chamberlain", 
     "b)" => "Kobe Bryant", 
     "c)" => "Larry Bird", 
     "resp" => "Wilt Chamberlain"],

    ["quest" => "Quin equip té més títols de la NBA?", 
     "a)" => "Los Angeles Lakers", 
     "b)" => "Chicago Bulls", 
     "c)" => "Boston Celtics", 
     "resp" => "Boston Celtics"],

    ["quest" => "Quin jugador és conegut com 'The King'?", 
     "a)" => "Kevin Durant", 
     "b)" => "LeBron James", 
     "c)" => "Stephen Curry", 
     "resp" => "LeBron James"],

    ["quest" => "Quin equip va guanyar la NBA el 2023?", 
     "a)" => "Miami Heat", 
     "b)" => "Denver Nuggets", 
     "c)" => "Golden State Warriors", 
     "resp" => "Denver Nuggets"],

    ["quest" => "Qui té més anells de campió com a jugador?", 
     "a)" => "Bill Russell", 
     "b)" => "Michael Jordan", 
     "c)" => "Magic Johnson", 
     "resp" => "Bill Russell"],

    ["quest" => "Quin jugador va ser famós pel 'Sky Hook'?", 
     "a)" => "Kareem Abdul-Jabbar", 
     "b)" => "Shaq", 
     "c)" => "Tim Duncan", 
     "resp" => "Kareem Abdul-Jabbar"],

    ["quest" => "Quin equip va tenir la temporada 73-9?", 
     "a)" => "Chicago Bulls", 
     "b)" => "Golden State Warriors", 
     "c)" => "Los Angeles Lakers", 
     "resp" => "Golden State Warriors"],

    ["quest" => "Quin jugador va guanyar 6 Finals MVP consecutives?", 
     "a)" => "Michael Jordan", 
     "b)" => "Kobe Bryant", 
     "c)" => "Magic Johnson", 
     "resp" => "Michael Jordan"],

    ["quest" => "Qui és conegut com 'The Big Diesel'?", 
     "a)" => "Shaquille O'Neal", 
     "b)" => "Dwight Howard", 
     "c)" => "Nikola Jokic", 
     "resp" => "Shaquille O'Neal"],

    ["quest" => "Quin jugador és famós pel seu triple?", 
     "a)" => "Stephen Curry", 
     "b)" => "Giannis Antetokounmpo", 
     "c)" => "Joel Embiid", 
     "resp" => "Stephen Curry"],

    ["quest" => "Quin equip juga al Madison Square Garden?", 
     "a)" => "Brooklyn Nets", 
     "b)" => "New York Knicks", 
     "c)" => "Boston Celtics", 
     "resp" => "New York Knicks"],

    ["quest" => "Qui va ser el primer MVP unànime?", 
     "a)" => "LeBron James", 
     "b)" => "Stephen Curry", 
     "c)" => "Kevin Durant", 
     "resp" => "Stephen Curry"],

    ["quest" => "Quin jugador és conegut com 'The Answer'?", 
     "a)" => "Allen Iverson", 
     "b)" => "Chris Paul", 
     "c)" => "Dwyane Wade", 
     "resp" => "Allen Iverson"],

    ["quest" => "Quin equip va guanyar tres títols seguits del 2000 al 2002?", 
     "a)" => "San Antonio Spurs", 
     "b)" => "Los Angeles Lakers", 
     "c)" => "Miami Heat", 
     "resp" => "Los Angeles Lakers"],

    ["quest" => "Quin jugador va ser draft número 1 el 2003?", 
     "a)" => "LeBron James", 
     "b)" => "Carmelo Anthony", 
     "c)" => "Dwyane Wade", 
     "resp" => "LeBron James"],

    ["quest" => "Quin jugador europeu ha guanyat més MVPs?", 
     "a)" => "Dirk Nowitzki", 
     "b)" => "Giannis Antetokounmpo", 
     "c)" => "Nikola Jokic", 
     "resp" => "Nikola Jokic"]
];


