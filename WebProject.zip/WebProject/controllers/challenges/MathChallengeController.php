<?php

print "<h1>Proximanent... encara has de apendre algunes coses més</h1>";