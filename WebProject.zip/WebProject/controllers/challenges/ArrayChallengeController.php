<?php

print "<h1>Proximanent... encara has de apendre algunes coses més</h1>";

//header('location: ../../views/challenges/ArrayChallengeView.php');
